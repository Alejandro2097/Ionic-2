export interface Comentario {
    usuario: string;
    pelicula: string;
    titulo_comentario: string;
    comentario: string;
    idPelicula: string;
}
