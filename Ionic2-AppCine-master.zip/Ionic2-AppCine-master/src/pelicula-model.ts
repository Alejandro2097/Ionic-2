export interface Pelicula {
    titulo: string;
    categoria: string;
    puntuacion: Number;
    imagen?: string;
}
