export interface User {
    username: string;
    password: string;
    name: string;
    email: string;
    telefono?: string;
    avatar?:string;
}
